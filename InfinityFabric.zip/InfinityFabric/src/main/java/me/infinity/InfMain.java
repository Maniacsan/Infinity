package me.infinity;

import me.infinity.features.HookManager;
import me.infinity.features.ModuleManager;
import me.zero.alpine.bus.EventBus;
import me.zero.alpine.bus.EventManager;

public class InfMain {

	public static InfMain INSTANCE = new InfMain();
	private static String name = "Infinity";
	private static String version = "1.5";
	private static EventBus eventBus = new EventManager();
	private static ModuleManager moduleManager;
	private static HookManager hookManager;

	public void initialize() {
		moduleManager = new ModuleManager();
		hookManager = new HookManager();
		eventBus.subscribe(ModuleManager.handlerPressKey);
		System.out.println("Injected bullshit");
	}

	public static String getName() {
		return name;
	}

	public static String getVersion() {
		return version;
	}

	public static ModuleManager getModuleManager() {
		return moduleManager;
	}

	public static HookManager getHookManager() {
		return hookManager;
	}

	public static EventBus getEventBus() {
		return eventBus;
	}
}