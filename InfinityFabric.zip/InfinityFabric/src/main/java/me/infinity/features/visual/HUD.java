package me.infinity.features.visual;

import org.lwjgl.opengl.GL11;

import me.infinity.event.HudRenderEvent;
import me.infinity.features.Module;
import me.infinity.features.ModuleInfo;
import me.infinity.utils.Helper;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.font.TextRenderer;

@ModuleInfo(category = Module.Category.VISUAL, desc = "Ingame Infinity Hud", key = 48, name = "HUD", visible = true)
public class HUD extends Module {

	@EventHandler
	public Listener<HudRenderEvent> onRender = new Listener<>(event -> {
		GL11.glPushMatrix();
		GL11.glScaled(0.5D, 0.5D, 0.5D);
		TextRenderer textRenderer = Helper.minecraftClient.textRenderer;
		textRenderer.draw(event.matrices, "Infinity", 3, 3, -1);
		GL11.glPopMatrix();
	});

	@Override
	public void onEnable() {
		Helper.getPlayer().sendChatMessage("Enabled");
		super.onEnable();
	}

	@Override
	public void onDisable() {
		Helper.getPlayer().sendChatMessage("Disable");
		super.onDisable();
	}

}
