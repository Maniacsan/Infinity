package me.infinity.features;

import me.infinity.InfMain;

public class HookManager {
	
	/**
	 * Update Client Player ticks (old method name onUpdate)
	 */
	public void onPlayerTick() {
		for (Module m : InfMain.getModuleManager().getList()) {
			if (m.isEnabled()) {
				m.onPlayerTick();
			}
		}
	}

}
