package me.infinity.features;

import java.lang.reflect.Method;

import me.infinity.InfMain;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listenable;

public abstract class Module implements Listenable {

	private Category category;
	private String desc;
	private String name;
	private int key;
	private boolean visible;
	private boolean enabled;

	public Module() {
		name = this.getClass().getAnnotation(ModuleInfo.class).name();
		setKey(this.getClass().getAnnotation(ModuleInfo.class).key());
		visible = this.getClass().getAnnotation(ModuleInfo.class).visible();
		setCategory(this.getClass().getAnnotation(ModuleInfo.class).category());
		desc = this.getClass().getAnnotation(ModuleInfo.class).desc();
	}

	public enum Category {
		COMBAT, MOVEMENT, WORLD, PLAYER, MISC, VISUAL
	}
	
	// HookManager methods
	public void onPlayerTick() {
	}
	
	//Fast use
	public void enable() {
		setEnabled(!isEnabled());
	}

	public void onEnable() {
	    for (Method method : getClass().getMethods()) {
	        if (method.isAnnotationPresent(EventHandler.class)) {
	          InfMain.getEventBus().subscribe(this);
	          break;
	        } 
	    }
	}

	public void onDisable() {
	    for (Method method : getClass().getMethods()) {
	        if (method.isAnnotationPresent(EventHandler.class)) {
	          InfMain.getEventBus().unsubscribe(this);
	          break;
	        } 
	    }
	}
	
	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
		if (enabled) {
			onEnable();
		} else {
			onDisable();
		}
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

}
