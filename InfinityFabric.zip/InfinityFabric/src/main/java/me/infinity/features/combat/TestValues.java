package me.infinity.features.combat;

import me.infinity.features.Module;
import me.infinity.features.ModuleInfo;
import me.infinity.features.value.BooleanValue;
import me.infinity.features.value.ModeValue;
import me.infinity.features.value.NumberValue;
import me.infinity.utils.Helper;

@ModuleInfo(category = Module.Category.COMBAT, desc = "TEST", key = 49, name = "TestValues", visible = true)
public class TestValues extends Module {
	
	private ModeValue testMode = new ModeValue("Mode", "Test", "TEST", "Test", "Test2");
	private BooleanValue testBool = new BooleanValue("Test Bool", true);
	private NumberValue<Double> testNum = new NumberValue<>("Test Num", 5.0D, 0.0D, 10.0D);
	private NumberValue<Integer> testInt = new NumberValue<>("Test Int", 5, 0, 10);
	
	public void onEnable() {
		Helper.getPlayer().sendChatMessage("i Enabled");
	}
	
	public void onDisable() {
		Helper.getPlayer().sendChatMessage("i Disabled");
	}

}
