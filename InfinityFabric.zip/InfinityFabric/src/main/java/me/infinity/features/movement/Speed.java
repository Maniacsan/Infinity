package me.infinity.features.movement;

import me.infinity.features.Module;
import me.infinity.features.ModuleInfo;
import me.infinity.utils.Helper;

@ModuleInfo(category = Module.Category.MOVEMENT, desc = "Make your motion to fast", key = 47, name = "Speed", visible = true)
public class Speed extends Module {

	@Override
	public void onPlayerTick() {
		if (Helper.getMoveUtil().isMoving()) {
			Helper.getMoveUtil().setSpeed(0.3);
		}
	}

}
