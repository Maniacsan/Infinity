package me.infinity.features;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.lwjgl.glfw.GLFW;

import me.infinity.event.KeyEvent;
import me.infinity.features.movement.Speed;
import me.infinity.features.movement.Sprint;
import me.infinity.features.visual.HUD;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

public class ModuleManager {

	private static List<Module> list = Arrays.asList(new Speed(), new HUD(), new Sprint());

	public List<Module> getList() {
		return list;
	}

	/**
	 * Importing feature module from class
	 * 
	 * @param clas
	 * @return
	 */
	public Module getModuleByClass(Class<?> clas) {
		Iterator<Module> iteratorMod = list.iterator();
		Module module;
		do {
			if (!iteratorMod.hasNext()) {
				return null;
			}
			module = (Module) iteratorMod.next();
		} while (module.getClass() != clas);
		return module;
	}

	/**
	 * Importing feature module from name
	 * 
	 * @param name
	 * @return
	 */
	public Module getModuleByName(String name) {
		for (Module m : list) {
			if (m.getName().equalsIgnoreCase(name)) {
				return m;
			}
		}
		return null;
	}

	@EventHandler
	public static Listener<KeyEvent> handlerPressKey = new Listener<>(eventKeyPress -> {
		if (InputUtil.isKeyPressed(MinecraftClient.getInstance().getWindow().getHandle(), GLFW.GLFW_KEY_F3))
			return;

		list.stream().filter(m -> m.getKey() == eventKeyPress.getKey()).forEach(Module::enable);
	});
}
