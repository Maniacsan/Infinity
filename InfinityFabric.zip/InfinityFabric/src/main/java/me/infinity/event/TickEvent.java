package me.infinity.event;

/**
 * event for MinecraftClient method = tick()
 * @author spray
 *
 */
public class TickEvent {
}