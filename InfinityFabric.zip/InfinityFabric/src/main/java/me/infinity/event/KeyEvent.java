package me.infinity.event;

import me.zero.alpine.event.type.Cancellable;

public class KeyEvent extends Cancellable {

	public int key;

	public int scancode;

	public KeyEvent(int key, int scancode) {
		this.key = key;
		this.scancode = scancode;
	}
	
	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

}
