package me.infinity.event;

import net.minecraft.client.util.math.MatrixStack;

/**
 * event for InGameHud method = render()
 * 
 * @author spray
 *
 */
public class HudRenderEvent {
	public MatrixStack matrices;
	public int screenWidth, screenHeight;
	public float tickDelta;

	public HudRenderEvent(MatrixStack matrices, int screenWidth, int screenHeight, float tickDelta) {
		this.matrices = matrices;
		this.screenHeight = screenWidth;
		this.screenHeight = screenHeight;
		this.tickDelta = tickDelta;
	}

}
